package com.example.uploadretriveimages;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter extends RecyclerView.Adapter< RecyclerViewAdapter.RecylerViewAdapter > {
    public RecyclerViewAdapter() {
    }

    public static class RecylerViewAdapter extends RecyclerView.ViewHolder {
        TextView imageNameTV;
        ImageView objectImageView;

        public RecylerViewAdapter(@NonNull View itemView) {
            super(itemView);
            imageNameTV=itemView.findViewById(R.id.sr_imageDetailsTV);
            objectImageView=itemView.findViewById(R.id.sr_imageIV);
        }
    }
}

